from django.shortcuts import render
from django.http import HttpResponse
from rest_framework.parsers import JSONParser
from rest_framework.decorators import api_view,parser_classes
from rest_framework.response import Response
from api.serializers import todoserilizer

from api.models import todo
# Create your views here.

@api_view(['POST'])
@parser_classes([JSONParser])
def createtodo(request):
    if {'content'}-set(request.data.keys())=={}:
        return Response({"error":"missing params","errorcode":1})
    t=todo(content=request.data['content'])
    try:
        t.save()
        return Response({"messege":"sucess"})
    except Exception as e: 
        print(e)
        return Response({"messege":"failed","error":"internal server error"})

@api_view(['POST'])
@parser_classes([JSONParser])
def deletetodo(request):
    if {'id'}-set(request.data.keys())=={}:
        return Response({"error":"missing params","errorcode":1})
    try:
        t=todo.objects.get(id=request.data["id"])
        m=t.delete()
        return Response({"messege":"sucess"})
    except Exception as e:
        print(e)
        return Response({"messege":"failed","error":"internal server error"})

@api_view(['GET'])
def getalltodo(request):
    t=todo.objects.all()
    tserialized=todoserilizer(t,many=True) 
    return Response(tserialized.data)

@api_view(['POST'])
@parser_classes([JSONParser])
def updatecomplete(request):
    if {'id'}-set(request.data.keys())=={}:
        return Response({"error":"missing params","errorcode":1})
    try:
        t=todo.objects.get(id=request.data["id"])
        t.completed=True
        t.save()
        return Response({"messege":"sucess"})
    except Exception as e:
        print(e)
        return Response({"messege":"failed","error":"internal server error"})