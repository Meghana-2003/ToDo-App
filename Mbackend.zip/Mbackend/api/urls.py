from django.urls import path

from api import admin, views

urlpatterns = [
    path("admin/", admin.site.urls),
    
]
