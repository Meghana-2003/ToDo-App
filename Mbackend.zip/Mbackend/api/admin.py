from django.contrib import admin
from api.models import todo
# Register your models here.
admin.site.register(todo)
