from rest_framework import serializers

from api.models import todo

class todoserilizer(serializers.ModelSerializer):
    class Meta:
        model=todo
        fields=['content','add_date','id','completed']
        