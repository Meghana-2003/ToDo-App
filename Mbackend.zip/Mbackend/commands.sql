CREATE DATABASE mytestdb;

CREATE USER 'test'@'localhost' IDENTIFIED BY 'Secret_1234';

GRANT ALL PRIVILEGES ON `mytestdb` . * TO 'test'@'localhost';

FLUSH PRIVILEGES; 