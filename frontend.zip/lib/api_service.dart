// // api_service.dart

// import 'dart:convert';
// import 'package:http/http.dart' as http;

// Future<void> createTodo() async {
//   const String apiUrl = 'http://http://127.0.0.1:8000//todo/';

//   var todoData = {
//     'content': 'Finish Flutter project',
//   };

//   var response = await http.post(
//     Uri.parse(apiUrl),
//     headers: <String, String>{
//       'Content-Type': 'application/json; charset=UTF-8',
//     },
//     body: jsonEncode(todoData),
//   );

//   if (response.statusCode == 201) {
//     print('Todo created successfully');
//   } else {
//     print('Failed to create todo: ${response.statusCode}');
//   }
// }

// import 'dart:convert'; // Required for JSON encoding/decoding
// import 'package:http/http.dart' as http;

// Future<void> postData() async {
//   var url = Uri.parse('http://127.0.0.1:8000/');
//   var headers = <String, String>{
//     'Content-Type': 'application/json; charset=UTF-8',
//   };
//   var body = jsonEncode(<String, String>{
//     'content': 'go to bookstore',
//   });

//   var response = await http.post(url, headers: headers, body: body);

//   if (response.statusCode == 200) {
//     // Successful POST request
//     print('Response body: ${response.body}');
//   } else {
//     // Error occurred
//     print('Failed to post data: ${response.statusCode}');
//   }
// }

// import 'dart:convert';
// import 'package:http/http.dart' as http;

// Future<void> addTask(String content) async {
//   var url = Uri.parse('http://127.0.0.1:8000/create/');
//   var headers = <String, String>{
//     'Content-Type': 'application/json; charset=UTF-8',
//   };
//   var body = jsonEncode(<String, String>{
//     'content': 'go to home',
//   });

//   var response = await http.post(url, headers: headers, body: body);

//   if (response.statusCode == 201) {
//     print('Task added successfully');
//   } else {
//     print('Failed to add task: ${response.statusCode}');
//   }
// }

// Future<void> deleteTask(int taskId) async {
//   var url = Uri.parse('http://127.0.0.1:8000/delete/$taskId/');
//   var response = await http.delete(url);

//   if (response.statusCode == 200) {
//     print('Task deleted successfully');
//   } else {
//     print('Failed to delete task: ${response.statusCode}');
//   }
// }
