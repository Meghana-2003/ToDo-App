// class ToDo {
//   String? id;
//   String? todoText;
//   bool isDone;

//   ToDo({
//     required this.id,
//     required this.todoText,
//     this.isDone = false,
//   });
//   static List<ToDo> todoList() {
//     return [
//       ToDo(
//         id: '01',
//         todoText: 'Morning exercise',
//         isDone: true,
//       ),
//       ToDo(
//         id: '02',
//         todoText: 'Buy Groceries',
//         isDone: true,
//       ),
//       ToDo(
//         id: '03',
//         todoText: 'check emails',
//         //isDone: true,
//       ),
//       ToDo(
//         id: '04',
//         todoText: 'team meeting',
//         // isDone: true,
//       ),
//       ToDo(
//         id: '05',
//         todoText: "dinner at 9pm",
//         // isDone: true,
//       ),
//       ToDo(
//         id: '06',
//         todoText: 'work on flutter for 2 hours',
//         //isDone: true,
//       ),
//     ];
//   }

//   // static fromMap(Map<String, dynamic> task) {}
//   factory ToDo.fromMap(Map<String, dynamic> map) {
//     return ToDo(
//       id: map['id'].toString(),
//       todoText: map['content'],
//       isDone: false, // Adjust if your backend has a field for isDone
//     );
//   }
// }

class ToDo {
  String id;
  String? todoText;
  bool isDone;

  ToDo({
    required this.id,
    this.todoText,
    this.isDone = false,
  });

  factory ToDo.fromMap(Map<String, dynamic> map) {
    return ToDo(
      id: map['id'].toString(),
      todoText: map['content'],
      isDone: false, // Adjust if your backend has a field for isDone
    );
  }

  static List<ToDo> todoList() {
    return [
      ToDo(
        id: '01',
        todoText: 'Morning Exercise',
      ),
      ToDo(
        id: '02',
        todoText: 'Buy Groceries',
      ),
      ToDo(
        id: '03',
        todoText: 'Check Emails',
      ),
      ToDo(
        id: '04',
        todoText: 'Team Meeting',
      ),
      ToDo(
        id: '05',
        todoText: 'Work on Mobile Apps for 2 hour',
      ),
      ToDo(
        id: '06',
        todoText: 'Dinner with Jenny',
      ),
    ];
  }
}
