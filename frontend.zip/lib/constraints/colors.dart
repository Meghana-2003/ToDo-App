import 'dart:ui';
import 'package:flutter/material.dart';

const Color tdRed = Color(0xFFDA4040);
const Color tdBlue = Color.fromARGB(201, 92, 64, 218);

const Color tdBlack = Color.fromARGB(255, 6, 6, 6);
const Color tdGrey = Color.fromARGB(255, 134, 115, 115);

const Color tdBGColor = Color.fromARGB(255, 246, 244, 244);
